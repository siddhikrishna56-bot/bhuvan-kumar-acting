/* ===================================================================
   BHUVAN KUMAR ACTING TRAINING INSTITUTE - INTERACTIVE CONTROLLER
   Pure 1-on-1 Personal Mentorship • Mobile Optimized
   =================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  initMobileNav();
  initFeeCalculator();
  initBookingForm();
  initFaqAccordion();
  initSmoothScroll();
});

/* -------------------------------------------------------------------
   1. Mobile Navigation & Touch Handler
   ------------------------------------------------------------------- */
function initMobileNav() {
  const hamburger = document.getElementById('hamburgerBtn');
  const navMenu = document.getElementById('navMenu');
  const navLinks = document.querySelectorAll('.nav-link');

  if (!hamburger || !navMenu) return;

  hamburger.addEventListener('click', (e) => {
    e.stopPropagation();
    navMenu.classList.toggle('open');
    const icon = hamburger.querySelector('i');
    if (icon) {
      icon.classList.toggle('fa-bars');
      icon.classList.toggle('fa-xmark');
    }
  });

  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      navMenu.classList.remove('open');
      const icon = hamburger.querySelector('i');
      if (icon) {
        icon.classList.add('fa-bars');
        icon.classList.remove('fa-xmark');
      }
    });
  });

  // Tap outside mobile drawer closes it
  document.addEventListener('click', (e) => {
    if (navMenu.classList.contains('open') && !navMenu.contains(e.target) && !hamburger.contains(e.target)) {
      navMenu.classList.remove('open');
      const icon = hamburger.querySelector('i');
      if (icon) {
        icon.classList.add('fa-bars');
        icon.classList.remove('fa-xmark');
      }
    }
  });
}

/* -------------------------------------------------------------------
   2. Interactive Fee Calculator & Custom Package Builder (₹2 Lakhs Base)
   ------------------------------------------------------------------- */
function initFeeCalculator() {
  const calcCheckboxes = document.querySelectorAll('.calc-checkbox');
  const totalDisplay = document.getElementById('calcTotalAmount');
  const whatsappCalcBtn = document.getElementById('calcWhatsappBtn');

  if (!totalDisplay) return;

  function calculateTotal() {
    let total = 0;
    const selectedItems = [];

    calcCheckboxes.forEach(cb => {
      const parentOption = cb.closest('.calc-option');
      if (cb.checked) {
        const price = parseInt(cb.getAttribute('data-price') || '0', 10);
        const name = cb.getAttribute('data-name') || 'Course';
        total += price;
        selectedItems.push(`${name} (₹${price.toLocaleString('en-IN')})`);
        if (parentOption) parentOption.classList.add('selected');
      } else {
        if (parentOption) parentOption.classList.remove('selected');
      }
    });

    totalDisplay.textContent = `₹${total.toLocaleString('en-IN')}/-`;

    // Update WhatsApp Inquire URL
    if (whatsappCalcBtn) {
      if (selectedItems.length === 0) {
        whatsappCalcBtn.href = `https://wa.me/919819192059?text=${encodeURIComponent(
          "Hello Bhuvan Kumar Sir, I am interested in 1-on-1 Personal Acting Training in Gokuldham Colony, Goregaon East, Mumbai. Please guide me regarding admission."
        )}`;
      } else {
        const message = `Hello Bhuvan Kumar Sir,\nI selected the following 1-on-1 private modules on your website:\n- ${selectedItems.join(
          '\n- '
        )}\nEstimated Total: ₹${total.toLocaleString('en-IN')}/-\n\nPlease share the available private appointment slots and admission process.`;
        whatsappCalcBtn.href = `https://wa.me/919819192059?text=${encodeURIComponent(message)}`;
      }
    }
  }

  calcCheckboxes.forEach(cb => {
    cb.addEventListener('change', calculateTotal);
    const parent = cb.closest('.calc-option');
    if (parent) {
      parent.addEventListener('click', (e) => {
        if (e.target !== cb) {
          cb.checked = !cb.checked;
          calculateTotal();
        }
      });
    }
  });

  calculateTotal();
}

/* -------------------------------------------------------------------
   3. Booking & Consultation Form (Direct WhatsApp & Fallback)
   ------------------------------------------------------------------- */
function initBookingForm() {
  const form = document.getElementById('auditionBookingForm');
  const alertBox = document.getElementById('formSuccessAlert');

  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('applicantName')?.value.trim();
    const phone = document.getElementById('applicantPhone')?.value.trim();
    const course = document.getElementById('applicantCourse')?.value;
    const experience = document.getElementById('applicantExperience')?.value;
    const note = document.getElementById('applicantNote')?.value.trim();

    if (!name || !phone) {
      alert("Please fill in your name and contact phone number.");
      return;
    }

    const textMessage = `🎬 *1-ON-1 ADMISSION / CONSULTATION INQUIRY*\n` +
      `*Institute:* Bhuvan Kumar Acting Training Institute (Reg No. 39459)\n` +
      `------------------------------------\n` +
      `👤 *Candidate:* ${name}\n` +
      `📞 *Phone:* ${phone}\n` +
      `🎭 *Course Selected:* ${course}\n` +
      `⭐ *Experience Level:* ${experience}\n` +
      (note ? `📝 *Aspirations / Goals:* ${note}\n` : '') +
      `------------------------------------\n` +
      `Location: A Wing, B-35, 401, Gokuldham Colony, Goregaon East, Mumbai 400063.\n` +
      `Please confirm available 1-on-1 appointment slots with Bhuvan Kumar Sir.`;

    const encoded = encodeURIComponent(textMessage);
    const whatsappUrl = `https://wa.me/919819192059?text=${encoded}`;

    if (alertBox) {
      alertBox.style.display = 'block';
    }

    // Open WhatsApp
    window.open(whatsappUrl, '_blank');
  });
}

/* -------------------------------------------------------------------
   4. FAQ Accordion
   ------------------------------------------------------------------- */
function initFaqAccordion() {
  const faqCards = document.querySelectorAll('.faq-card');

  faqCards.forEach(card => {
    const question = card.querySelector('.faq-question');
    if (!question) return;

    question.addEventListener('click', () => {
      const isOpen = card.classList.contains('open');

      // Close all
      faqCards.forEach(c => c.classList.remove('open'));

      // If wasn't open, open current
      if (!isOpen) {
        card.classList.add('open');
      }
    });
  });
}

/* -------------------------------------------------------------------
   5. Smooth Scrolling & Active Nav Highlighting
   ------------------------------------------------------------------- */
function initSmoothScroll() {
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  window.addEventListener('scroll', () => {
    let current = '';
    const scrollPosition = window.pageYOffset + 120;

    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.offsetHeight;
      if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
        current = section.getAttribute('id');
      }
    });

    navLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('active');
      }
    });
  });
}
